import fresh_tomatoes
import media1

'''multiple instances of the class Movie'''
golmaal_again = media1.Movie("Golmaal Again",
                             "https://upload"
                             ".wikimedia.org/"
                             "wikipedia/en/thumb/4/49/"
                             "Ajay_Devgn%27s_Golmaal_Again_"
                             "poster.jpg/220px-Ajay_Devgn"
                             "%27s_Golmaal_Again_poster.jpg",
                             "https://www.youtube.com/watch?v=VgQUwsUHdqc")

bahubali_2 = media1.Movie("Bahubali 2 - The Conclusion",
                          "https://upload.wikimedia.org/"
                          "wikipedia/en/f/f9/Baahubali_the_"
                          "Conclusion.jpg",
                          "https://www.youtube.com/watch?v=G62HrubdD6o")

jolly_llb_2 = media1.Movie("JOLLY LL.B 2",
                           "https://upload.wikimedia.org/wikipedia/en/thumb"
                           "/4/4b/Jolly_LLB_2_first_look.jpg/220px-Jolly_LLB"
                           "_2_"
                           "first_look.jpg",
                           "https://www.youtube.com/watch?v=q07SQFmL4rM")


movies = [golmaal_again, bahubali_2, jolly_llb_2]
fresh_tomatoes.open_movies_page(movies)
