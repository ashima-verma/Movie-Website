<br />

# Movie Trailer Website

<br />

The Movie Trailer Website project consists of server-side code to store a list of movies titles, along with its respective box art imagery and movie trailer website. The data should be served as a web page allowing visitors to review the movies and watch the trailers.

<br />

##Includes
----------
The zip file contains the following files:

- media1.py

- instances.py

- fresh_tomatoes.py

- FullStackProject1.md

##Execution
-----------
 - Run the file `instance.py` on `Python IDE` which is an executable file. Then you will be able to see a webpage showing the list of movies. Then by clicking on any movie poster, the trailer of the movie will launch.

## Features
-----------
  - Simple home page where movies are laid out

  - Page allows users to click on a movie image to watch its trailer

<br />

## Functionality
-----------
  - Page is dynamically generated from a `Python` data structure.

  - Page does present required content (movie title, box art and trailer link.

  - Page is error free.

<br />

## Code Quality
-----------
 - Code is ready for personal review and neatly formatted.

 - It follows the Python  `PEP-8 Guidelines`
 
<br />

## Comments
-----------
 - Comments effectively explain longer code procedures.

<br />

